package cn.kgc.entity;

public class P {
    private String pid;
    private String pname;
    private float price;
    private int pnu;
    private int wnu;
    private String pintrog;
    private String cname;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getPnu() {
        return pnu;
    }

    public void setPnu(int pnu) {
        this.pnu = pnu;
    }

    public int getWnu() {
        return wnu;
    }

    public void setWnu(int wnu) {
        this.wnu = wnu;
    }

    public String getPintrog() {
        return pintrog;
    }

    public void setPintrog(String pintrog) {
        this.pintrog = pintrog;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
}
